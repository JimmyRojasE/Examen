-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: examen_wm
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `core_producto`
--

DROP TABLE IF EXISTS `core_producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `core_producto` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) NOT NULL,
  `precio` int NOT NULL,
  `precio_promocion` int NOT NULL,
  `stock` int NOT NULL,
  `imagen` varchar(250) NOT NULL,
  `id_categoria_id` bigint NOT NULL,
  `id_estado_producto_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `core_producto_id_categoria_id_7d17e0ff_fk_core_categoria_id` (`id_categoria_id`),
  KEY `core_producto_id_estado_producto_i_48a2a348_fk_core_esta` (`id_estado_producto_id`),
  CONSTRAINT `core_producto_id_categoria_id_7d17e0ff_fk_core_categoria_id` FOREIGN KEY (`id_categoria_id`) REFERENCES `core_categoria` (`id`),
  CONSTRAINT `core_producto_id_estado_producto_i_48a2a348_fk_core_esta` FOREIGN KEY (`id_estado_producto_id`) REFERENCES `core_estado_producto` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `core_producto`
--

LOCK TABLES `core_producto` WRITE;
/*!40000 ALTER TABLE `core_producto` DISABLE KEYS */;
INSERT INTO `core_producto` VALUES (1,'Bandana1',3990,2990,10,'https://laikamascotas.cl/cdn-cgi/image/onerror=redirect,format=auto,fit=scale-down,width=300,quality=80/https://laikapp.s3.amazonaws.com/dev_images_products/75380_Simona_Mascotas___Bandana_Pinkpr_1644597265_0_500x500.png',1,1),(3,'Bandana2',49990,29990,10,'https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcTUttvYiLH7dCImRrDHRZsQLSV2dAc6I-FZ6iPZnh4VvYYizd159ks1Flo-UHvHKJay0ktAWmK0JD0&usqp=CAc',1,1),(4,'Correa1',17990,14990,3,'https://www.hogarmania.com/archivos/202103/elegir-collar-arne-perro-portada3-1280x720x80xX.jpg',2,1),(5,'collar',9990,8990,9,'https://cdn.shopify.com/s/files/1/2656/3744/products/CollarHusky_Cafe.jpg?v=1601405958',2,1),(6,'identificador',5990,4990,10,'https://bestforpets.cl/tienda/9542-large_default/chapa-big-circle-paw.jpg',3,1);
/*!40000 ALTER TABLE `core_producto` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-14 13:44:10
